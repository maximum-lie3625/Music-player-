package com.example.remixplayer

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Deck(context: Context) {
    private val appContext = context.applicationContext
    private val player = ExoPlayer.Builder(appContext).build()

    var track by mutableStateOf<Track?>(null)
        private set
    var bpm by mutableStateOf<Float?>(null)
        private set
    var analyzing by mutableStateOf(false)
        private set
    var playing by mutableStateOf(false)
        private set
    var tempo by mutableFloatStateOf(1f)
        private set
    var keyLock by mutableStateOf(true)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set

    /** BPM you actually hear after the tempo slider. */
    val effectiveBpm: Float? get() = bpm?.let { it * tempo }

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        })
    }

    fun load(t: Track, scope: CoroutineScope) {
        track = t
        bpm = null
        analyzing = true
        tempo = 1f
        player.setMediaItem(MediaItem.fromUri(t.uri))
        player.prepare()
        applyParams()
        scope.launch {
            val result = withContext(Dispatchers.Default) { BpmDetector.detect(appContext, t.uri) }
            if (track === t) { bpm = result; analyzing = false }
        }
    }

    private fun applyParams() {
        player.playbackParameters = PlaybackParameters(tempo, if (keyLock) 1f else tempo)
    }

    fun setTempo(v: Float) { tempo = v.coerceIn(0.8f, 1.25f); applyParams() }
    fun toggleKeyLock() { keyLock = !keyLock; applyParams() }
    fun toggle() {
        if (track == null) return
        if (player.isPlaying) player.pause() else player.play()
    }
    fun pause() = player.pause()
    fun seekToFraction(f: Float) { if (durationMs > 0) player.seekTo((durationMs * f).toLong()) }
    fun nudge(ms: Long) { player.seekTo((player.currentPosition + ms).coerceAtLeast(0L)) }
    fun setGain(g: Float) { player.volume = g.coerceIn(0f, 1f) }
    fun scaleBpm(factor: Float) { bpm = bpm?.let { (it * factor).coerceIn(40f, 220f) } }

    /** Match this deck's heard BPM to the other deck's heard BPM. */
    fun syncTo(o: Deck) {
        val mine = bpm ?: return
        val theirs = o.effectiveBpm ?: return
        setTempo(theirs / mine)
    }

    fun tick() {
        positionMs = player.currentPosition
        durationMs = player.duration.coerceAtLeast(0L)
    }

    fun release() = player.release()
}
