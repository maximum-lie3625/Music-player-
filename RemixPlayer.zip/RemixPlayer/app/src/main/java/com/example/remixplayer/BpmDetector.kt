package com.example.remixplayer

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.sqrt

/** Decodes ~25s of the track, builds a low-frequency energy envelope, finds tempo by autocorrelation. */
object BpmDetector {
    private const val ENV_RATE = 200

    fun detect(ctx: Context, uri: Uri): Float? = try {
        tempoFrom(envelope(ctx, uri, 20, 25))
    } catch (e: Exception) {
        null
    }

    private fun envelope(ctx: Context, uri: Uri, startSec: Int, lenSec: Int): FloatArray {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    idx = i; fmt = f; break
                }
            }
            if (idx < 0 || fmt == null) return FloatArray(0)
            ex.selectTrack(idx)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            if (durUs > (startSec + lenSec) * 1_000_000L) {
                ex.seekTo(startSec * 1_000_000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            }
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var hop = sr / ENV_RATE
            val env = ArrayList<Float>()
            val maxFrames = ENV_RATE * lenSec
            val info = MediaCodec.BufferInfo()
            var lp = 0f
            var acc = 0.0
            var n = 0
            var inDone = false
            var outDone = false
            var guard = 0

            while (!outDone && env.size < maxFrames && guard++ < 20000) {
                if (!inDone) {
                    val i = c.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = c.getInputBuffer(i)!!
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) {
                            c.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(i, 0, size, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = c.dequeueOutputBuffer(info, 10_000)
                if (o >= 0) {
                    val buf = c.getOutputBuffer(o)
                    if (buf != null && info.size > 0) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val s = buf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        while (s.remaining() >= ch) {
                            var m = 0f
                            for (k in 0 until ch) m += s.get()
                            m /= ch * 32768f
                            lp += 0.08f * (m - lp)
                            acc += (lp * lp).toDouble()
                            n++
                            if (n >= hop) {
                                env.add(sqrt(acc / n).toFloat())
                                acc = 0.0
                                n = 0
                            }
                        }
                    }
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                    c.releaseOutputBuffer(o, false)
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    hop = sr / ENV_RATE
                }
            }
            return env.toFloatArray()
        } finally {
            try { codec?.stop(); codec?.release() } catch (e: Exception) { }
            ex.release()
        }
    }

    private fun tempoFrom(env: FloatArray): Float? {
        val n = env.size
        if (n < ENV_RATE * 8) return null
        val onset = FloatArray(n)
        for (i in 1 until n) onset[i] = max(0f, env[i] - env[i - 1])
        val mean = onset.average().toFloat()
        for (i in 0 until n) onset[i] -= mean

        var best = Float.NEGATIVE_INFINITY
        var bestBpm = 0f
        var bpm = 70f
        while (bpm <= 180f) {
            val lag = 60f / bpm * ENV_RATE
            val score = acf(onset, lag) + 0.5f * acf(onset, lag * 2)
            if (score > best) { best = score; bestBpm = bpm }
            bpm += 0.5f
        }
        if (bestBpm <= 0f) return null
        while (bestBpm < 80f) bestBpm *= 2
        while (bestBpm > 170f) bestBpm /= 2
        return Math.round(bestBpm * 10) / 10f
    }

    private fun acf(o: FloatArray, lag: Float): Float {
        val l = lag.toInt()
        val fr = lag - l
        var s = 0f
        for (i in 0 until o.size - l - 1) s += o[i] * (o[i + l] * (1 - fr) + o[i + l + 1] * fr)
        return s / (o.size - l)
    }
}
