package com.example.remixplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri, val durationMs: Long)

object Library {
    fun load(ctx: Context): List<Track> {
        val out = ArrayList<Track>()
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000"
        val order = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        ctx.contentResolver.query(base, proj, sel, null, order)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iT = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iA = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iD = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.add(
                    Track(
                        id,
                        c.getString(iT) ?: "Unknown",
                        c.getString(iA) ?: "Unknown",
                        ContentUris.withAppendedId(base, id),
                        c.getLong(iD)
                    )
                )
            }
        }
        return out
    }
}
